import requests

def fetch_data(url):
    res = requests.get(url)
    return res.json()

def process_order(order_id):
    try:
        return fetch_data("https://api.example.com/orders")
    except Exception:
        pass
